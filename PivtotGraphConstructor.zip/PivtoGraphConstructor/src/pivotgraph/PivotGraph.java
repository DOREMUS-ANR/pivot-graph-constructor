package pivotgraph;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.rdf.model.StmtIterator;
import org.apache.jena.vocabulary.OWL;
import org.apache.jena.vocabulary.RDF;
import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.Cell;

import fr.inrialpes.exmo.align.parser.AlignmentParser;
import sameAs.Link;
import sameAs.LinkList;

public class PivotGraph {

	public static void main(String[] args) throws AlignmentException, IOException, URISyntaxException {
		
		Model d1Model = ModelFactory.createDefaultModel();
		Model d2Model = ModelFactory.createDefaultModel();
		Model d3Model = ModelFactory.createDefaultModel();
		
		Model pgModel = ModelFactory.createDefaultModel();
		
		InputStream d1In =new FileInputStream(new File ("C:/eclipse/workspace/PivotGraph/store/pp.ttl"));
		InputStream d2In =new FileInputStream(new File ("C:/eclipse/workspace/PivotGraph/store/bnf.ttl"));
		InputStream d3In =new FileInputStream(new File ("C:/eclipse/workspace/PivotGraph/store/rf.ttl"));

		int surelinks=0;
		int linkstovalid=0;
		int createlinks=0;
		int inferredlinks =0;
		int plus = 0;
		int noEqPP = 0;
		int noEqBNF = 0;
		int noEqRF = 0;
		/***************
		 * Models loading
		 ***************/
		System.out.println("Models loading ...");
		d1Model.read(d1In, null ,"TTL"); // pp
		d2Model.read(d2In, null ,"TTL"); // bnf
		d3Model.read(d3In, null ,"TTL"); //rf
		
		/***************
		 * Links loading
		 ***************/
		System.out.println("Links loading ...");
		AlignmentParser aparser = new AlignmentParser(0);
		Alignment results = aparser.parse( new File( "C:/eclipse/workspace/PivotGraph/store/finalResults.rdf" ).toURI() );
		List<Cell> list = Collections.list(results.getElements());
		LinkList linkList = new LinkList();
		for (Cell cell : list)
		{
			Link link = new Link(cell.getObject1().toString(), cell.getObject2().toString(),cell.getStrength());
			linkList.add(link);
		}
		
		/**************************
		 * Pivot graph construction
		 **************************/
		
		System.out.println("Pivot graph construction ...");
		
		StmtIterator iter1 = d1Model.listStatements();
		while (iter1.hasNext()){ 
			Statement stmt      = iter1.nextStatement();  
			List<String> obj2_1 = new ArrayList<String>(); //Level 1 = Les objects de la 1ere ressource
			Resource res = stmt.getSubject();
			if (hasType(res)==true)
			{
				String subj = res.toString(); // Pour chaque ressource Rp de la PP
				obj2_1 = linkList.getObj2OfURI1(subj); // Extraire ses equivalences de la BNF
				
				/************
				 * Safe Links 
				 ************/
				if (obj2_1.size()==1) // Si Rp a une seule ressource equivalente Rb
				{
					List<String> obj2_2 = new ArrayList<String>(); 
					obj2_2 = linkList.getObj2OfURI1(obj2_1.get(0)); // Extraire les equivalences a Rb de RF
					if (obj2_2.size()==1) // Si Rb a une seule ressource equivalente Rr
					{
						List<String> obj2_3 = new ArrayList<String>(); 
						obj2_3 = linkList.getObj2OfURI1(obj2_2.get(0)); // Extraire les equivalences a Rr de PP
						if (obj2_3.size()==1) // Si Rr a une seule ressource equivalente Rp
						{
							if (obj2_3.get(0).equals(subj)) //Case 1 = sure links
							{
							//	System.out.println("sure links");
								surelinks= surelinks+1;
								String identifier1 = getID(d1Model, subj);
								String identifier2 = getID(d2Model, obj2_1.get(0));
								String identifier3 = getID(d3Model, obj2_2.get(0)); 
								Resource rsrce = pgModel.createResource((ConstructURI.build("pp", identifier1, "bnf", identifier2, "rf", identifier3, "F22_SelfContainedExpression")).toString());
								rsrce.addProperty(OWL.sameAs, pgModel.createResource(subj));
								rsrce.addProperty(OWL.sameAs, pgModel.createResource(obj2_1.get(0)));
								rsrce.addProperty(OWL.sameAs, pgModel.createResource(obj2_2.get(0)));
							}
							else // Case 3 = conflit
							{
							//	System.out.println("links to validate");
								linkstovalid = linkstovalid+1;
							}
						}
						else if (obj2_3.size()==0) //<Rp = Rb> & <Rb = Rr> mais nous ne trouvons pas d'equivalence de Rr avec PP
						{
							double sim1= linkList.getSimScore(subj, obj2_1.get(0));
							double sim2= linkList.getSimScore(obj2_1.get(0), obj2_1.get(0));
							if (sim1==1 & sim2==1) // Si les 2 liens ont une similarite=1 alors on infere le 3eme lien et on cree un URI pivot
							{
								Link link = new Link(obj2_2.get(0), subj,1);
								linkList.add(link);
								inferredlinks = inferredlinks+1;
								surelinks= surelinks+1;
								String identifier1 = getID(d1Model, subj);
								String identifier2 = getID(d2Model, obj2_1.get(0));
								String identifier3 = getID(d3Model, obj2_2.get(0)); 
								Resource rsrce = pgModel.createResource((ConstructURI.build("pp", identifier1, "bnf", identifier2, "rf", identifier3, "F22_SelfContainedExpression")).toString());
								rsrce.addProperty(OWL.sameAs, pgModel.createResource(subj));
								rsrce.addProperty(OWL.sameAs, pgModel.createResource(obj2_1.get(0)));
								rsrce.addProperty(OWL.sameAs, pgModel.createResource(obj2_2.get(0)));
							}
						}
					}
					else if (obj2_2.size()==0) //Case 2 
					{
							createlinks = createlinks+1;
							String identifier1 = getID(d1Model, subj);
							String identifier2 = getID(d2Model, obj2_1.get(0));
							Resource rsrce = pgModel.createResource((ConstructURI.build("pp", identifier1, "bnf", identifier2, "F22_SelfContainedExpression")).toString());
							rsrce.addProperty(OWL.sameAs, pgModel.createResource(subj));
							rsrce.addProperty(OWL.sameAs, pgModel.createResource(obj2_1.get(0)));
					}
				}
				else if (obj2_1.size()>1)
				{
					System.out.println("plusieurs");
					plus = plus+1;
				}
			}
		}
		
		
		// Creer un URI pivot pour chaque ressource qui n'a pas du tout d'equivalence
		List<String> classnames = new ArrayList<String>();
		classnames.add("http://erlangen-crm.org/efrbroo/F22_Self-Contained_Expression");
		
		List<Resource> ppRsrces = getResources(d1Model, classnames);
		for (Resource res: ppRsrces)
		{
			String resPP = res.toString();
			if (linkList.hasEquivalence(resPP)==false)
			{
				noEqPP = noEqPP +1;
				String identifier1 = getID(d1Model, resPP);
				Resource rsrce = pgModel.createResource((ConstructURI.build("pp", identifier1, "F22_SelfContainedExpression")).toString());
				rsrce.addProperty(OWL.sameAs, pgModel.createResource(resPP));
			}
		}
		
		List<Resource> bnfRsrces = getResources(d2Model, classnames);
		for (Resource res: bnfRsrces)
		{
			String resBNF = res.toString();
			if (linkList.hasEquivalence(resBNF)==false)
			{
				noEqBNF = noEqBNF +1;
				String identifier2 = getID(d2Model, resBNF);
				Resource rsrce = pgModel.createResource((ConstructURI.build("bnf", identifier2, "F22_SelfContainedExpression")).toString());
				rsrce.addProperty(OWL.sameAs, pgModel.createResource(resBNF));
			}
		}
		
		List<Resource> rfRsrces = getResources(d3Model, classnames);
		for (Resource res: rfRsrces)
		{
			String resRF = res.toString();
			if (linkList.hasEquivalence(resRF)==false)
			{
				noEqRF = noEqRF +1;
				String identifier3 = getID(d3Model, resRF);
				Resource rsrce = pgModel.createResource((ConstructURI.build("rf", identifier3, "F22_SelfContainedExpression")).toString());
				rsrce.addProperty(OWL.sameAs, pgModel.createResource(resRF));
			}
		}
		
		System.out.println("sure links = "+ surelinks);
		System.out.println("links to validate = "+ linkstovalid);
		System.out.println("created links = "+ createlinks);
		System.out.println("plusieurs liens = "+ plus);
		System.out.println("liens inferres = "+ inferredlinks);
		System.out.println("ressources PP uniques = "+ noEqPP);
		System.out.println("ressources BNF uniques = "+ noEqBNF);
		System.out.println("ressources RF uniques = "+ noEqRF);
		
		FileWriter out = new FileWriter("C:/eclipse/workspace/PivotGraph/store/pivotgraph.rdf");
		pgModel.write( out, "RDF/XML");
		out.close();
		

	}

	public static boolean hasType (Resource resource)
	{
		boolean is = false;
		Model model = ModelFactory.createDefaultModel();
		Resource classResource = model.createResource("http://erlangen-crm.org/efrbroo/F22_Self-Contained_Expression");
		if (resource.hasProperty(RDF.type, classResource))
		{
			is = true;
		}
		return is;
	}
	
	public static String getID (Model model, String rsrc)
	{
			String id = "";
			String sparqlQueryString = 
					   "PREFIX p1: <http://erlangen-crm.org/efrbroo/>"+
					   "PREFIX p2: <http://purl.org/dc/terms/>"+
					   "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"+
					   "select ?id where {"+ 
					   "<"+rsrc+"> a p1:F22_Self-Contained_Expression ."+
					   "<"+rsrc+"> p2:identifier ?id ."+
					   "}";
			Query query = QueryFactory.create(sparqlQueryString);
			QueryExecution qexec = QueryExecutionFactory.create(query, model);
			ResultSet queryResults = qexec.execSelect();
			while (queryResults.hasNext()) {
				QuerySolution qs = queryResults.nextSolution();
				id = id+ qs.getLiteral("?id").toString()+" ";
			}
			return id.trim();
	}
	
	/*****************************************************
	 * Get all resources of a given class from an RDF model 
	 *****************************************************/
	public static List<Resource> getResources(Model model, List<String> classnames) {
		List<Resource> results = new ArrayList<Resource>();
		for (String classname : classnames)
		{
			String sparqlQueryString = "SELECT DISTINCT ?s { ?s a <"+classname+"> }";
			Query query = QueryFactory.create(sparqlQueryString);
			QueryExecution qexec = QueryExecutionFactory.create(query, model);
			ResultSet queryResults = qexec.execSelect();
			while (queryResults.hasNext()) {
				QuerySolution qs = queryResults.nextSolution();
				results.add(qs.getResource("?s"));
			}
			qexec.close();
		}
		return results;
	}
}
